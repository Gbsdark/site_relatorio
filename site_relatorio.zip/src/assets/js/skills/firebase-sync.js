/**
 * ============================================================================
 * SKILL: FIREBASE CLOUD SYNC (BACKUP RESILIENTE EM NUVEM)
 * Arquivo: src/assets/js/skills/firebase-sync.js
 * 
 * Responsabilidades:
 * - Sincronização em segundo plano dos dados da ata para o Google Cloud Firestore
 * - Mecanismo de fila offline (Queue): retém o backup no LocalStorage se estiver sem internet
 * - Re-sincronização automática assim que a conexão 3G/4G/Wi-Fi for restabelecida
 * - Não-bloqueante: a operação do formulário e exportação de PDF nunca dependem do Firebase
 * ============================================================================
 */

(function (global) {
  'use strict';

  // Chaves de armazenamento da fila no LocalStorage
  const SYNC_STORAGE_KEYS = {
    PENDING_BACKUP: 'gb_firebase_pending_backup',
    LAST_SYNC: 'gb_firebase_last_sync_timestamp'
  };

  /**
   * Configuração padrão do Firebase.
   * Substitua os valores abaixo pelas credenciais do seu projeto Firebase Console.
   */
  const DEFAULT_FIREBASE_CONFIG = {
    apiKey: "SUA_API_KEY_AQUI",
    authDomain: "seu-projeto.firebaseapp.com",
    projectId: "seu-projeto-id",
    storageBucket: "seu-projeto.appspot.com",
    messagingSenderId: "123456789",
    appId: "1:123456789:web:abcdef"
  };

  let firestoreDb = null;
  let isInitialized = false;
  let isSyncing = false;
  let activeConfig = { ...DEFAULT_FIREBASE_CONFIG };

  /**
   * Verifica se o Firebase SDK foi carregado e se as credenciais foram configuradas.
   * @returns {boolean}
   */
  function isConfigured() {
    const hasSdk = typeof firebase !== 'undefined' && typeof firebase.firestore === 'function';
    const isMockKey = !activeConfig.apiKey || activeConfig.apiKey.includes('SUA_API_KEY');
    return hasSdk && !isMockKey;
  }

  /**
   * Inicializa o aplicativo Firebase e o Firestore.
   * @param {object} [customConfig] Configuração personalizada opcional
   */
  function init(customConfig) {
    if (customConfig) {
      activeConfig = { ...activeConfig, ...customConfig };
    }

    if (!isConfigured()) {
      console.info('[Firebase Sync] Firebase em modo Standby. Configure as credenciais no arquivo "firebase-sync.js" para habilitar o envio em nuvem.');
      setupReconnectionListener();
      return false;
    }

    try {
      if (!firebase.apps.length) {
        firebase.initializeApp(activeConfig);
      }
      firestoreDb = firebase.firestore();

      // Habilita persistência offline do próprio Firestore (se suportado pelo navegador)
      firestoreDb.enablePersistence({ synchronizeTabs: true }).catch((err) => {
        if (err.code === 'failed-precondition') {
          console.warn('[Firebase Sync] Múltiplas abas abertas; persistência ativa apenas na primeira.');
        } else if (err.code === 'unimplemented') {
          console.warn('[Firebase Sync] Este navegador não suporta persistência nativa do Firestore.');
        }
      });

      isInitialized = true;
      console.log('[Firebase Sync] Conectado ao Firebase Firestore com sucesso.');

      setupReconnectionListener();

      // Se houver dados pendentes na fila local, tenta sincronizar imediatamente
      if (navigator.onLine && hasPendingSync()) {
        syncPendingBackup();
      }

      return true;
    } catch (err) {
      console.warn('[Firebase Sync] Falha ao inicializar Firebase:', err);
      return false;
    }
  }

  /**
   * Gera um identificador único e legível para a ata no Firestore.
   * Ex: "ATA_2026-11-12_Shopping_Rio_Sul_Loja_204"
   * @param {object} formData 
   * @returns {string}
   */
  function generateDocumentId(formData) {
    const date = formData.dataImplantacao || new Date().toISOString().split('T')[0];
    const rawUnidade = formData.unidadePraca || 'Sem_Unidade';
    const cleanUnidade = rawUnidade.replace(/[^a-zA-Z0-9À-ÿ_-]/g, '_').substring(0, 40);
    return `ATA_${date}_${cleanUnidade}`;
  }

  /**
   * Adiciona ou atualiza a ata na fila local de backup.
   * Dispara o envio imediato se estiver online.
   * @param {object} formData - Dados de campos
   * @param {string|null} photoData - Base64 da foto
   * @param {object|null} signaturesData - Base64 das assinaturas
   */
  function queueBackup(formData, photoData, signaturesData) {
    if (!formData || typeof formData !== 'object') return;

    const docId = generateDocumentId(formData);
    const payload = {
      docId: docId,
      unidadePraca: formData.unidadePraca || '',
      dataImplantacao: formData.dataImplantacao || '',
      razaoSocial: formData.razaoSocial || '',
      cnpj: formData.cnpj || '',
      formData: formData,
      // Metadados sobre evidências e assinaturas
      hasEvidenciaPhoto: !!photoData,
      signaturesSummary: {
        responsavelTI: !!(signaturesData && signaturesData.sigTI),
        responsavelOperacao: !!(signaturesData && signaturesData.sigOperacao),
        responsavelUnidade: !!(signaturesData && signaturesData.sigUnidade)
      },
      updatedAtClient: new Date().toISOString(),
      platform: navigator.platform || 'Desconhecida'
    };

    // 1. Sempre armazena o estado atual na fila do LocalStorage primeiro (Offline-First)
    try {
      localStorage.setItem(SYNC_STORAGE_KEYS.PENDING_BACKUP, JSON.stringify(payload));
    } catch (storageErr) {
      console.warn('[Firebase Sync] Erro ao salvar fila no LocalStorage:', storageErr);
    }

    // 2. Se houver conexão com a internet e o Firebase estiver ativo, sincroniza em segundo plano
    if (navigator.onLine && isConfigured()) {
      syncPendingBackup();
    } else {
      console.log('[Firebase Sync] Dispositivo offline ou Firebase não configurado. Backup retido na fila local.');
    }
  }

  /**
   * Envia o backup pendente do LocalStorage para a coleção 'atas_operacionais' no Firestore.
   * @returns {Promise<boolean>}
   */
  async function syncPendingBackup() {
    if (isSyncing) return false;

    const rawPending = localStorage.getItem(SYNC_STORAGE_KEYS.PENDING_BACKUP);
    if (!rawPending) {
      return false;
    }

    if (!isConfigured() || !firestoreDb) {
      return false;
    }

    if (!navigator.onLine) {
      console.log('[Firebase Sync] Conexão indisponível. Aguardando reestabelecimento da rede.');
      return false;
    }

    isSyncing = true;
    try {
      const payload = JSON.parse(rawPending);
      const docId = payload.docId || generateDocumentId(payload.formData || {});

      // Salva ou faz merge dos dados na coleção corporativa do Firestore
      await firestoreDb.collection('atas_operacionais').doc(docId).set({
        ...payload,
        syncedAtServer: firebase.firestore.FieldValue.serverTimestamp(),
        syncStatus: 'SYNCHRONIZED'
      }, { merge: true });

      // Atualiza carimbo de última sincronização com sucesso
      const now = new Date().toISOString();
      localStorage.setItem(SYNC_STORAGE_KEYS.LAST_SYNC, now);
      localStorage.removeItem(SYNC_STORAGE_KEYS.PENDING_BACKUP);

      console.log('[Firebase Sync] Backup sincronizado na nuvem com sucesso:', docId);

      // Dispara evento customizado para notificação na UI
      window.dispatchEvent(new CustomEvent('gb-firebase-synced', {
        detail: { docId, syncedAt: now }
      }));

      isSyncing = false;
      return true;
    } catch (err) {
      console.warn('[Firebase Sync] Falha ao enviar para o Firestore (tentará novamente quando online):', err);
      isSyncing = false;
      return false;
    }
  }

  /**
   * Configura o ouvinte para sincronizar automaticamente quando o dispositivo reconectar à internet.
   */
  function setupReconnectionListener() {
    window.addEventListener('online', () => {
      console.log('[Firebase Sync] Conexão restabelecida! Tentando esvaziar fila de backup pendente...');
      if (hasPendingSync()) {
        syncPendingBackup();
      }
    });
  }

  /**
   * Verifica se há algum backup aguardando envio na fila local.
   * @returns {boolean}
   */
  function hasPendingSync() {
    return !!localStorage.getItem(SYNC_STORAGE_KEYS.PENDING_BACKUP);
  }

  /**
   * Retorna a data/hora da última sincronização bem-sucedida.
   * @returns {string|null}
   */
  function getLastSyncTime() {
    return localStorage.getItem(SYNC_STORAGE_KEYS.LAST_SYNC);
  }

  // Exportação Global Universal
  const GBFirebaseSync = {
    init,
    queueBackup,
    syncPendingBackup,
    isConfigured,
    hasPendingSync,
    getLastSyncTime
  };

  global.GBFirebaseSync = GBFirebaseSync;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = GBFirebaseSync;
  }
})(typeof window !== 'undefined' ? window : this);
