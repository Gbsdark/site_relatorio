/**
 * ============================================================================
 * SERVICE WORKER - ATA OPERACIONAL (GRUPO BURGUÊS)
 * Arquivo: service-worker.js (Localizado na raiz para ter escopo global "./")
 * 
 * Funcionalidades:
 * - Cache-First para recursos estáticos da aplicação (App Shell)
 * - Suporte completo à operação offline em auditorias sem conexão 3G/4G
 * - Ciclo de vida robusto com limpeza automática de caches antigos
 * ============================================================================
 */

const CACHE_NAME = 'gb-ata-cache-v1.0.0';

// Lista de arquivos estáticos essenciais para funcionamento 100% offline
const PRECACHE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './src/assets/css/style.css',
  './src/assets/css/style.css?v=2.1',
  './src/assets/js/html2pdf.bundle.min.js',
  './src/assets/js/canvas.js',
  './src/assets/js/storage.js',
  './src/assets/js/skills/pwa-manager.js',
  './src/assets/js/skills/firebase-sync.js',
  './src/assets/js/main.js',
  './src/assets/img/logo-grupo-burgues.png',
  './src/assets/img/logo-grupo-burgues-dark.png',
  './src/assets/img/logo-grupo-burgues-white.png',
  './src/assets/img/icons/icon-192x192.png',
  './src/assets/img/icons/icon-512x512.png'
];

/**
 * Evento INSTALL: Faz o pré-cache dos arquivos fundamentais da aplicação
 */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      console.log('[ServiceWorker] Pré-carregando App Shell no cache:', CACHE_NAME);
      // Pré-carrega cada item de forma resiliente
      for (const asset of PRECACHE_ASSETS) {
        try {
          await cache.add(asset);
        } catch (err) {
          console.warn('[ServiceWorker] Aviso ao cachear asset:', asset, err);
        }
      }
    }).then(() => self.skipWaiting())
  );
});

/**
 * Evento ACTIVATE: Limpa caches obsoletos de versões anteriores
 */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('[ServiceWorker] Removendo cache obsoleto:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

/**
 * Evento FETCH: Estratégia de Cache-First com Fallback de Rede
 */
self.addEventListener('fetch', (event) => {
  const request = event.request;

  // Ignora requisições não-GET e esquemas não suportados (ex: chrome-extension)
  if (request.method !== 'GET' || !request.url.startsWith('http')) {
    return;
  }

  // Não intercepta chamadas externas do Firebase Firestore para não interferir no SDK
  if (request.url.includes('firestore.googleapis.com') || request.url.includes('firebaseio.com')) {
    return;
  }

  // Requisições de navegação (HTML): Network-First com fallback para cache
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((networkResponse) => {
          return caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, networkResponse.clone());
            return networkResponse;
          });
        })
        .catch(() => {
          return caches.match('./index.html') || caches.match(request);
        })
    );
    return;
  }

  // Requisições de ativos estáticos (CSS, JS, Imagens, Fontes): Cache-First
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) {
        // Atualiza o cache em segundo plano (Stale-While-Revalidate suave)
        fetch(request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, networkResponse);
            });
          }
        }).catch(() => {/* Offline - mantém versão do cache */});

        return cachedResponse;
      }

      // Se não estava em cache, busca na rede e guarda para as próximas execuções
      return fetch(request).then((networkResponse) => {
        if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
          return networkResponse;
        }

        const responseToCache = networkResponse.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(request, responseToCache);
        });

        return networkResponse;
      }).catch((err) => {
        console.warn('[ServiceWorker] Recurso indisponível offline:', request.url);
        throw err;
      });
    })
  );
});
