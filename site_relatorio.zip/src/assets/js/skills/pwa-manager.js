/**
 * ============================================================================
 * SKILL: PWA MANAGER (PROGRESSIVE WEB APP LIFECYCLE)
 * Arquivo: src/assets/js/skills/pwa-manager.js
 * 
 * Responsabilidades:
 * - Registro e verificação de compatibilidade do Service Worker
 * - Detecção de atualizações do App Shell em segundo plano
 * - Captura e disparo do evento de instalação (Add to Home Screen / PWA Install)
 * - Monitoramento em tempo real do estado online / offline do dispositivo
 * - Proteção contra falhas em execuções locais via protocolo file:///
 * ============================================================================
 */

(function (global) {
  'use strict';

  let deferredInstallPrompt = null;
  let serviceWorkerRegistration = null;

  /**
   * Verifica se o ambiente atual suporta Service Worker e PWA.
   * Service Workers exigem HTTPS ou localhost (não funcionam sob protocolo file://).
   * @returns {boolean}
   */
  function isPwaSupported() {
    const isLocalFile = window.location.protocol === 'file:';
    return ('serviceWorker' in navigator) && !isLocalFile;
  }

  /**
   * Retorna o estado atual da conexão com a internet.
   * @returns {boolean}
   */
  function isOnline() {
    return navigator.onLine;
  }

  /**
   * Registra o Service Worker principal da aplicação.
   */
  function registerServiceWorker() {
    if (!isPwaSupported()) {
      if (window.location.protocol === 'file:') {
        console.info('[PWA Manager] Execução via protocolo file:// detectada. Service Worker desativado localmente (requer servidor HTTPS ou localhost).');
      } else {
        console.warn('[PWA Manager] Este navegador não suporta Service Workers.');
      }
      return Promise.resolve(null);
    }

    return navigator.serviceWorker.register('./service-worker.js', { scope: './' })
      .then((registration) => {
        serviceWorkerRegistration = registration;
        console.log('[PWA Manager] Service Worker registrado com sucesso. Escopo:', registration.scope);

        // Detecta novas versões disponíveis do aplicativo
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                console.info('[PWA Manager] Nova versão disponível em cache.');
                window.dispatchEvent(new CustomEvent('gb-pwa-update-ready'));
              }
            });
          }
        });

        return registration;
      })
      .catch((err) => {
        console.warn('[PWA Manager] Falha no registro do Service Worker:', err);
        return null;
      });
  }

  /**
   * Configura os ouvintes do prompt de instalação do aplicativo no dispositivo.
   */
  function setupInstallListeners() {
    window.addEventListener('beforeinstallprompt', (event) => {
      // Impede que o mini-infobar padrão apareça imediatamente no mobile
      event.preventDefault();
      deferredInstallPrompt = event;
      console.log('[PWA Manager] Aplicativo elegível para instalação.');

      // Dispara evento customizado para que a interface possa exibir botão "Instalar App"
      window.dispatchEvent(new CustomEvent('gb-pwa-installable', { detail: { event } }));
    });

    window.addEventListener('appinstalled', () => {
      deferredInstallPrompt = null;
      console.log('[PWA Manager] Ata Operacional instalada com sucesso como PWA.');
      window.dispatchEvent(new CustomEvent('gb-pwa-installed'));
    });
  }

  /**
   * Dispara o diálogo oficial de instalação no dispositivo do usuário.
   * @returns {Promise<boolean>} Retorna true se o usuário aceitou a instalação
   */
  function promptInstall() {
    if (!deferredInstallPrompt) {
      console.warn('[PWA Manager] O prompt de instalação não está disponível no momento.');
      return Promise.resolve(false);
    }

    return deferredInstallPrompt.prompt()
      .then(() => deferredInstallPrompt.userChoice)
      .then((choiceResult) => {
        const accepted = choiceResult.outcome === 'accepted';
        console.log('[PWA Manager] Resposta do usuário à instalação:', choiceResult.outcome);
        deferredInstallPrompt = null;
        return accepted;
      })
      .catch((err) => {
        console.warn('[PWA Manager] Erro ao disparar prompt de instalação:', err);
        return false;
      });
  }

  /**
   * Configura listeners de conectividade (Online / Offline).
   */
  function setupConnectivityListeners() {
    const handleStatusChange = () => {
      const online = isOnline();
      console.log(`[PWA Manager] Conectividade alterada: ${online ? 'ONLINE' : 'OFFLINE'}`);

      window.dispatchEvent(new CustomEvent('gb-connection-changed', {
        detail: { online }
      }));
    };

    window.addEventListener('online', handleStatusChange);
    window.addEventListener('offline', handleStatusChange);
  }

  /**
   * Inicializa toda a skill de PWA.
   */
  function init() {
    setupInstallListeners();
    setupConnectivityListeners();

    // Registra o Service Worker após a carga completa da janela
    if (document.readyState === 'complete') {
      registerServiceWorker();
    } else {
      window.addEventListener('load', registerServiceWorker);
    }
  }

  // Exportação Global Universal
  const GBPWAManager = {
    init,
    isOnline,
    isPwaSupported,
    promptInstall,
    hasInstallPrompt: () => !!deferredInstallPrompt,
    getRegistration: () => serviceWorkerRegistration
  };

  global.GBPWAManager = GBPWAManager;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = GBPWAManager;
  }
})(typeof window !== 'undefined' ? window : this);
